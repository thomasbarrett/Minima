#!/usr/bin/env bash

kill -9 $1;
rm -r $2
echo "Hello"